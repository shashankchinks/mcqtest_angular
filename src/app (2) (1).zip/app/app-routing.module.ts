import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { InstructionPageComponent } from './components/instruction-page/instruction-page.component';
import { QuestionPageComponent } from './components/question-page/question-page.component';
import { ThankyouPageComponent } from './components/thankyou-page/thankyou-page.component';
import { AboutUsComponent } from './components/about-us/about-us.component';
import { ContactUsComponent } from './components/contact-us/contact-us.component';

const routes: Routes = [
  {path:'login',component:LoginComponent},
  {path:'instruction',component:InstructionPageComponent},
  {path:'question',component:QuestionPageComponent},
  {path:'last',component:ThankyouPageComponent},
  {path:'aboutus',component:AboutUsComponent},
  {path:'contactus',component:ContactUsComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
