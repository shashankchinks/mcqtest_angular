export class StudentDetails {
    public name:string;
    public mobile:string;
    public email:string;
}
