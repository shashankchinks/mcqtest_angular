import { StartTestDetail } from './start-test-detail';

describe('StartTestDetail', () => {
  it('should create an instance', () => {
    expect(new StartTestDetail()).toBeTruthy();
  });
});
