export class StartTestDetail {
    public code: string;
    public mobile: string;
}
