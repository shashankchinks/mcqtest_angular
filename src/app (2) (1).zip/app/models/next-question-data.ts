export class NextQuestionData {
    public answer:string;
    public code:string;
    public mobile:string;
    public questionId:string;
}
