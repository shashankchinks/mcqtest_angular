import { NextQuestionData } from './next-question-data';

describe('NextQuestionData', () => {
  it('should create an instance', () => {
    expect(new NextQuestionData()).toBeTruthy();
  });
});
